import hashlib

def sha256_string(data):
    return hashlib.sha256(data.encode()).hexdigest()

def sha256_file(file_path):
    sha256 = hashlib.sha256()
    with open(file_path, "rb") as f:
        for block in iter(lambda: f.read(4096), b""):
            sha256.update(block)
    return sha256.hexdigest()
