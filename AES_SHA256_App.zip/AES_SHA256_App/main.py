from aes_app import encrypt_aes, decrypt_aes
from sha256_hasher import sha256_string, sha256_file

def main():
    while True:
        print("\n--- MENÜ ---")
        print("1. AES Şifreleme")
        print("2. AES Şifre Çözme")
        print("3. SHA256 Özetle (Metin)")
        print("4. SHA256 Özetle (Dosya)")
        print("0. Çıkış")
        secim = input("Seçiminiz: ")

        if secim == "1":
            text = input("Şifrelenecek metni girin: ")
            key = input("Anahtar (16 karakterden kısa olabilir): ")
            encrypted = encrypt_aes(text, key)
            print(f"Şifrelenmiş metin: {encrypted}")

        elif secim == "2":
            encrypted = input("Şifreli metni girin: ")
            key = input("Anahtar: ")
            try:
                decrypted = decrypt_aes(encrypted, key)
                print(f"Çözülen metin: {decrypted}")
            except:
                print("Şifre çözmede hata! Anahtar veya veri yanlış olabilir.")

        elif secim == "3":
            text = input("Özeti alınacak metni girin: ")
            print("SHA256 özeti:", sha256_string(text))

        elif secim == "4":
            path = input("Dosya yolu: ")
            try:
                print("SHA256 özeti:", sha256_file(path))
            except:
                print("Dosya bulunamadı!")

        elif secim == "0":
            break
        else:
            print("Geçersiz seçim!")

if __name__ == "__main__":
    main()
